var searchData=
[
  ['reflectance_20with_20spin_20orbit_20effects_0',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]],
  ['riflesso_3a_20em_20ab_20initio_20em_20reflectance_20with_20spin_20orbit_20effects_1',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]]
];
