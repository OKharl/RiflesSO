var searchData=
[
  ['ab_20initio_20em_20reflectance_20with_20spin_20orbit_20effects_0',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]],
  ['added_1',['Physical effects described and to be added',['../index.html#autotoc_md3',1,'']]],
  ['adiabaticreflectionsolver_2',['AdiabaticReflectionSolver',['../classsrc_1_1reflsolver__adiabatic_1_1AdiabaticReflectionSolver.html',1,'src::reflsolver_adiabatic']]],
  ['and_20to_20be_20added_3',['Physical effects described and to be added',['../index.html#autotoc_md3',1,'']]],
  ['authors_20current_20status_4',['Authors, current status, ...',['../index.html#autotoc_md4',1,'']]]
];
