var searchData=
[
  ['boundary_5flattice_5fvectors_0',['boundary_lattice_vectors',['../classsrc_1_1lattice_1_1CrystallineHalfSpace.html#a4fb61d167c58f11a1d24bc6487bbb735',1,'src::lattice::CrystallineHalfSpace']]],
  ['boundary_5fpotential_5fkdirection_1',['boundary_potential_kdirection',['../classsrc_1_1lattice_1_1CrystallineHalfSpace.html#a7ae9d2da9799981b0af6658d91f6af47',1,'src::lattice::CrystallineHalfSpace']]]
];
