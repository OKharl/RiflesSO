var searchData=
[
  ['wannierelectronicstructure_0',['WannierElectronicStructure',['../classsrc_1_1elecstructure_1_1WannierElectronicStructure.html',1,'src::elecstructure']]],
  ['with_20spin_20orbit_20effects_1',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]]
];
