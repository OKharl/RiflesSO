var searchData=
[
  ['electronic_5fstates_5fbz_0',['electronic_states_bz',['../classsrc_1_1elecstructure_1_1ElectronicStructure.html#afb9e1ad3d39adc7dc9e2aadfd113c450',1,'src.elecstructure.ElectronicStructure.electronic_states_BZ()'],['../classsrc_1_1elecstructure_1_1WannierElectronicStructure.html#afb9e1ad3d39adc7dc9e2aadfd113c450',1,'src.elecstructure.WannierElectronicStructure.electronic_states_BZ()']]]
];
