var searchData=
[
  ['described_20and_20to_20be_20added_0',['Physical effects described and to be added',['../index.html#autotoc_md3',1,'']]]
];
