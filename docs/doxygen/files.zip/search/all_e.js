var searchData=
[
  ['to_20be_20added_0',['Physical effects described and to be added',['../index.html#autotoc_md3',1,'']]]
];
