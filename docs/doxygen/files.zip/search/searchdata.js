var indexSectionsWithContent =
{
  0: "_abcdefikloprstuw",
  1: "_abcekrw",
  2: "_bcefiklprs",
  3: "aeiorsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

