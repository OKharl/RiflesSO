var searchData=
[
  ['reflectionsolver_0',['ReflectionSolver',['../classsrc_1_1reflsolver_1_1ReflectionSolver.html',1,'src::reflsolver']]],
  ['reflectiontask_1',['ReflectionTask',['../classsrc_1_1riflesso__main_1_1ReflectionTask.html',1,'src::riflesso_main']]],
  ['reflector_2',['Reflector',['../classsrc_1_1projector_1_1Reflector.html',1,'src::projector']]],
  ['riflesso_3',['RiflesSO',['../classsrc_1_1riflesso__main_1_1RiflesSO.html',1,'src::riflesso_main']]]
];
