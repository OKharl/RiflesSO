var searchData=
[
  ['kpoints_0',['kpoints',['../classsrc_1_1projector_1_1Kgrid.html#a5dc24938a41decc1b961050ee8e8b12d',1,'src::projector::Kgrid']]]
];
