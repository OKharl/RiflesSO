var searchData=
[
  ['snap_5fto_5frational_5fboundary_0',['snap_to_rational_boundary',['../classsrc_1_1lattice_1_1CrystallineHalfSpace.html#aeab65aaf241cc03ea0bf412fa208e830',1,'src::lattice::CrystallineHalfSpace']]],
  ['spin_20orbit_20effects_1',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]],
  ['status_2',['Authors, current status, ...',['../index.html#autotoc_md4',1,'']]]
];
