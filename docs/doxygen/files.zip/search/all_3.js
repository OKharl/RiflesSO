var searchData=
[
  ['closest_5fpoint_5findex_0',['closest_point_index',['../classsrc_1_1projector_1_1Kgrid.html#a0de2419f289817ee85b74f9379546236',1,'src::projector::Kgrid']]],
  ['command_20line_1',['Usage: Command line',['../index.html#autotoc_md2',1,'']]],
  ['crystallattice_2',['CrystalLattice',['../classsrc_1_1lattice_1_1CrystalLattice.html',1,'src::lattice']]],
  ['crystallinehalfspace_3',['CrystallineHalfSpace',['../classsrc_1_1lattice_1_1CrystallineHalfSpace.html',1,'src::lattice']]],
  ['current_20status_4',['Authors, current status, ...',['../index.html#autotoc_md4',1,'']]]
];
