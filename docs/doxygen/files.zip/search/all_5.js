var searchData=
[
  ['effects_0',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]],
  ['effects_20described_20and_20to_20be_20added_1',['Physical effects described and to be added',['../index.html#autotoc_md3',1,'']]],
  ['electronic_5fstates_5fbz_2',['electronic_states_bz',['../classsrc_1_1elecstructure_1_1ElectronicStructure.html#afb9e1ad3d39adc7dc9e2aadfd113c450',1,'src.elecstructure.ElectronicStructure.electronic_states_BZ()'],['../classsrc_1_1elecstructure_1_1WannierElectronicStructure.html#afb9e1ad3d39adc7dc9e2aadfd113c450',1,'src.elecstructure.WannierElectronicStructure.electronic_states_BZ()']]],
  ['electronicstructure_3',['ElectronicStructure',['../classsrc_1_1elecstructure_1_1ElectronicStructure.html',1,'src::elecstructure']]],
  ['em_20ab_20initio_20em_20reflectance_20with_20spin_20orbit_20effects_4',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]]
];
