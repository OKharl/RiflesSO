var searchData=
[
  ['snap_5fto_5frational_5fboundary_0',['snap_to_rational_boundary',['../classsrc_1_1lattice_1_1CrystallineHalfSpace.html#aeab65aaf241cc03ea0bf412fa208e830',1,'src::lattice::CrystallineHalfSpace']]]
];
