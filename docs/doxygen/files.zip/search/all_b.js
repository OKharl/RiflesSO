var searchData=
[
  ['physical_20effects_20described_20and_20to_20be_20added_0',['Physical effects described and to be added',['../index.html#autotoc_md3',1,'']]],
  ['point_5findex_5fscalar2vector_1',['point_index_scalar2vector',['../classsrc_1_1projector_1_1Kgrid.html#a7ff982432d27c0f7573c66d64aad534c',1,'src::projector::Kgrid']]],
  ['potential_5finv_5ffunction_2',['potential_inv_function',['../classsrc_1_1boundarypot_1_1BoundaryPotential.html#a363850d6db1b087004849b80f7c9d4f7',1,'src.boundarypot.BoundaryPotential.potential_inv_function()'],['../classsrc_1_1boundarypot_1_1KinkPotential.html#a363850d6db1b087004849b80f7c9d4f7',1,'src.boundarypot.KinkPotential.potential_inv_function()']]],
  ['potential_5fvalue_3',['potential_value',['../classsrc_1_1boundarypot_1_1BoundaryPotential.html#a9514eabf2c9101941d28875b221e9206',1,'src::boundarypot::BoundaryPotential']]],
  ['propagate_5fband_5fin_5fbz_4',['propagate_band_in_BZ',['../classsrc_1_1elecstructure_1_1ElectronicStructure.html#a62b2063a051e734d49ebf0d3c57aea25',1,'src::elecstructure::ElectronicStructure']]],
  ['propagate_5fband_5fin_5fenergy_5',['propagate_band_in_energy',['../classsrc_1_1elecstructure_1_1ElectronicStructure.html#aa909ad12855ed26f985a85f0445ee5cd',1,'src::elecstructure::ElectronicStructure']]],
  ['python_20library_6',['Usage: Python library',['../index.html#autotoc_md1',1,'']]]
];
