var searchData=
[
  ['be_20added_0',['Physical effects described and to be added',['../index.html#autotoc_md3',1,'']]],
  ['blochstate_1',['BlochState',['../classsrc_1_1elecstructure_1_1BlochState.html',1,'src::elecstructure']]],
  ['boundary_5flattice_5fvectors_2',['boundary_lattice_vectors',['../classsrc_1_1lattice_1_1CrystallineHalfSpace.html#a4fb61d167c58f11a1d24bc6487bbb735',1,'src::lattice::CrystallineHalfSpace']]],
  ['boundary_5fpotential_5fkdirection_3',['boundary_potential_kdirection',['../classsrc_1_1lattice_1_1CrystallineHalfSpace.html#a7ae9d2da9799981b0af6658d91f6af47',1,'src::lattice::CrystallineHalfSpace']]],
  ['boundarypotential_4',['BoundaryPotential',['../classsrc_1_1boundarypot_1_1BoundaryPotential.html',1,'src::boundarypot']]]
];
