var searchData=
[
  ['closest_5fpoint_5findex_0',['closest_point_index',['../classsrc_1_1projector_1_1Kgrid.html#a0de2419f289817ee85b74f9379546236',1,'src::projector::Kgrid']]]
];
