var searchData=
[
  ['from_5fdictionary_0',['from_dictionary',['../classsrc_1_1boundarypot_1_1BoundaryPotential.html#a0fe7763a3af248e21656b47783d95120',1,'src.boundarypot.BoundaryPotential.from_dictionary()'],['../classsrc_1_1elecstructure_1_1ElectronicStructure.html#a0b1ca9381bafb3fe515b8c34477698c1',1,'src.elecstructure.ElectronicStructure.from_dictionary()'],['../classsrc_1_1reflsolver_1_1ReflectionSolver.html#a4f2940e97f0aa9f2be9c520defa7e65a',1,'src.reflsolver.ReflectionSolver.from_dictionary()']]]
];
