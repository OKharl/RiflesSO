var searchData=
[
  ['real_5fvector_5fto_5ffractional_5fcoords_0',['real_vector_to_fractional_coords',['../classsrc_1_1lattice_1_1CrystalLattice.html#ae407f7ba0713951c40246ecec199427b',1,'src::lattice::CrystalLattice']]],
  ['reciprocal_5fvector_5fto_5ffractional_5fcoords_1',['reciprocal_vector_to_fractional_coords',['../classsrc_1_1lattice_1_1CrystalLattice.html#a6bedbf177c7682b7fc85e7a67e0c558d',1,'src::lattice::CrystalLattice']]],
  ['reflect_5fdensity_5fmatrix_2',['reflect_density_matrix',['../classsrc_1_1reflsolver_1_1ReflectionSolver.html#a7a6350e6cbf89235fff52143b24727c4',1,'src::reflsolver::ReflectionSolver']]],
  ['reflect_5fwavefunction_3',['reflect_wavefunction',['../classsrc_1_1reflsolver_1_1ReflectionSolver.html#a4e83f67f23d0677d1e5d7404dda64d2b',1,'src.reflsolver.ReflectionSolver.reflect_wavefunction()'],['../classsrc_1_1reflsolver__adiabatic_1_1AdiabaticReflectionSolver.html#a4e83f67f23d0677d1e5d7404dda64d2b',1,'src.reflsolver_adiabatic.AdiabaticReflectionSolver.reflect_wavefunction()']]],
  ['run_4',['run',['../classsrc_1_1riflesso__main_1_1ReflectionTask.html#a425e082f55bb25e24d4f32bc91b2439d',1,'src::riflesso_main::ReflectionTask']]]
];
