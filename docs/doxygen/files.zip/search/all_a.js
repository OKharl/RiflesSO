var searchData=
[
  ['orbit_20effects_0',['RiflesSO: &lt;em&gt;ab initio&lt;/em&gt; reflectance with spin-orbit effects',['../index.html',1,'']]]
];
